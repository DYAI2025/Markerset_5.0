#!/usr/bin/env python3
"""
Clean existing markers and run fresh migration
"""

import logging
from pymongo import MongoClient
import sys

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_database(mongodb_uri: str, database_name: str):
    """Clean existing marker data"""
    try:
        client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=30000)
        db = client[database_name]
        
        logger.info("🗑️  Cleaning existing collections...")
        
        # Drop collections to avoid index conflicts
        collections_to_clean = ['markers', 'marker_examples', 'detection_schemas']
        
        for collection_name in collections_to_clean:
            if collection_name in db.list_collection_names():
                db[collection_name].drop()
                logger.info(f"✅ Dropped collection: {collection_name}")
            else:
                logger.info(f"ℹ️  Collection doesn't exist: {collection_name}")
        
        client.close()
        logger.info("✅ Database cleaned successfully!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error cleaning database: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 clean_and_migrate.py <mongodb_uri> <database_name>")
        sys.exit(1)
    
    mongodb_uri = sys.argv[1]
    database_name = sys.argv[2]
    
    if clean_database(mongodb_uri, database_name):
        logger.info("🚀 Ready for fresh migration!")
    else:
        logger.error("❌ Failed to clean database")
        sys.exit(1)