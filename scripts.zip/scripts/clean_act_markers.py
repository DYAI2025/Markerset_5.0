#!/usr/bin/env python3
"""
Clean ACT markers from MongoDB - these seem to be artifacts from another AI system
"""

import logging
from pymongo import MongoClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def clean_act_markers(mongodb_uri: str, database_name: str):
    """Remove ACT markers from database"""
    try:
        client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=10000)
        db = client[database_name]
        
        logger.info("🧹 Cleaning ACT markers...")
        
        # Find ACT markers
        act_markers = list(db.markers.find({"category": "ACTION"}))
        act_marker_ids = [marker["id"] for marker in act_markers]
        
        logger.info(f"📊 Found {len(act_markers)} ACT markers: {act_marker_ids}")
        
        if act_markers:
            # Delete ACT markers
            result = db.markers.delete_many({"category": "ACTION"})
            logger.info(f"🗑️  Deleted {result.deleted_count} ACT markers")
            
            # Delete associated examples
            if act_marker_ids:
                example_result = db.marker_examples.delete_many({"marker_id": {"$in": act_marker_ids}})
                logger.info(f"🗑️  Deleted {example_result.deleted_count} ACT examples")
            
            # Update detection schema
            db.detection_schemas.update_one(
                {"_id": "wordthread_production_schema"},
                {"$pullAll": {"markers": act_marker_ids}}
            )
            logger.info("🔧 Updated detection schema")
            
            # Update statistics
            schema = db.detection_schemas.find_one({"_id": "wordthread_production_schema"})
            if schema:
                updated_stats = {
                    "total_markers": len(schema["markers"]),
                    "ato_markers": db.markers.count_documents({"category": "ATOMIC"}),
                    "sem_markers": db.markers.count_documents({"category": "SEMANTIC"}),
                    "clu_markers": db.markers.count_documents({"category": "CLUSTER"}),
                    "mema_markers": db.markers.count_documents({"category": "META"}),
                    "act_markers": 0
                }
                
                db.detection_schemas.update_one(
                    {"_id": "wordthread_production_schema"},
                    {"$set": {"statistics": updated_stats}}
                )
                logger.info("📊 Updated schema statistics")
        else:
            logger.info("ℹ️  No ACT markers found to clean")
        
        # Final counts
        final_counts = {
            "ATOMIC": db.markers.count_documents({"category": "ATOMIC"}),
            "SEMANTIC": db.markers.count_documents({"category": "SEMANTIC"}),
            "CLUSTER": db.markers.count_documents({"category": "CLUSTER"}),
            "META": db.markers.count_documents({"category": "META"}),
            "ACTION": db.markers.count_documents({"category": "ACTION"}),
            "TOTAL": db.markers.count_documents({})
        }
        
        logger.info("📊 Final marker counts:")
        for category, count in final_counts.items():
            logger.info(f"   {category}: {count}")
        
        client.close()
        logger.info("✅ ACT marker cleanup completed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error cleaning ACT markers: {str(e)}")
        return False

if __name__ == "__main__":
    mongodb_uri = "mongodb+srv://Zoe0403:Zoe0403@markerengine.3ed5u3.mongodb.net/?retryWrites=true&w=majority&appName=MarkerEngine"
    database_name = "MarkerEngine"
    
    clean_act_markers(mongodb_uri, database_name)