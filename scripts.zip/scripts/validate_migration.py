#!/usr/bin/env python3
"""
MongoDB Migration Validator für WORDthread_lab
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Validiert die Migration und testet die Marker-Detection
"""

import logging
from pymongo import MongoClient
from typing import Dict, List, Any, Optional
import argparse
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MigrationValidator:
    """Validates successful marker migration"""
    
    def __init__(self, mongodb_uri: str, database_name: str = "wordthread_markers"):
        self.mongodb_uri = mongodb_uri
        self.database_name = database_name
        self.client: Optional[MongoClient] = None
        self.db = None
        
    def connect(self) -> bool:
        """Connect to MongoDB"""
        try:
            logger.info(f"🔄 Connecting to MongoDB...")
            self.client = MongoClient(self.mongodb_uri, serverSelectionTimeoutMS=10000)
            self.client.admin.command('ping')
            self.db = self.client[self.database_name]
            logger.info("✅ Connected successfully!")
            return True
        except Exception as e:
            logger.error(f"❌ Connection failed: {str(e)}")
            return False
    
    def validate_collections(self) -> Dict[str, Any]:
        """Validates all collections exist and have correct structure"""
        logger.info("📊 Validating collections...")
        
        results = {}
        expected_collections = ['markers', 'marker_examples', 'detection_schemas', 'migration_log']
        
        for collection_name in expected_collections:
            collection = self.db[collection_name]
            count = collection.count_documents({})
            
            results[collection_name] = {
                'exists': count > 0,
                'count': count,
                'sample': collection.find_one() if count > 0 else None
            }
            
            if count > 0:
                logger.info(f"✅ {collection_name}: {count} documents")
            else:
                logger.warning(f"⚠️  {collection_name}: Empty or missing")
        
        return results
    
    def validate_marker_categories(self) -> Dict[str, int]:
        """Validates marker distribution by categories"""
        logger.info("🔍 Analyzing marker categories...")
        
        pipeline = [
            {"$group": {"_id": "$category", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}}
        ]
        
        categories = {}
        for result in self.db.markers.aggregate(pipeline):
            categories[result['_id']] = result['count']
            logger.info(f"📂 {result['_id']}: {result['count']} markers")
        
        return categories
    
    def validate_examples(self) -> Dict[str, Any]:
        """Validates marker examples"""
        logger.info("📝 Validating examples...")
        
        total_examples = self.db.marker_examples.count_documents({})
        markers_with_examples = self.db.marker_examples.distinct('marker_id')
        
        # Average examples per marker
        avg_examples = total_examples / len(markers_with_examples) if markers_with_examples else 0
        
        results = {
            'total_examples': total_examples,
            'markers_with_examples': len(markers_with_examples),
            'average_examples_per_marker': round(avg_examples, 2)
        }
        
        logger.info(f"📊 Total examples: {total_examples}")
        logger.info(f"📊 Markers with examples: {len(markers_with_examples)}")
        logger.info(f"📊 Average examples per marker: {results['average_examples_per_marker']}")
        
        return results
    
    def test_marker_queries(self) -> List[Dict[str, Any]]:
        """Tests various marker queries"""
        logger.info("🧪 Testing marker queries...")
        
        test_cases = [
            {
                'name': 'Find ATO markers',
                'query': {'category': 'ATOMIC'},
                'expected_min': 100  # We expect at least 100 ATO markers
            },
            {
                'name': 'Find markers with patterns',
                'query': {'pattern': {'$exists': True, '$ne': []}},
                'expected_min': 50
            },
            {
                'name': 'Find markers with examples',
                'query': {'example_count': {'$gt': 0}},
                'expected_min': 200
            },
            {
                'name': 'Find German markers',
                'query': {'lang': 'de'},
                'expected_min': 300
            }
        ]
        
        results = []
        for test in test_cases:
            count = self.db.markers.count_documents(test['query'])
            passed = count >= test['expected_min']
            
            result = {
                'test': test['name'],
                'count': count,
                'expected_min': test['expected_min'],
                'passed': passed
            }
            results.append(result)
            
            status = "✅" if passed else "❌"
            logger.info(f"{status} {test['name']}: {count} results (min: {test['expected_min']})")
        
        return results
    
    def test_detection_schema(self) -> Dict[str, Any]:
        """Tests detection schema"""
        logger.info("🔧 Testing detection schema...")
        
        schema = self.db.detection_schemas.find_one({'_id': 'wordthread_production_schema'})
        
        if not schema:
            logger.error("❌ Production schema not found!")
            return {'exists': False}
        
        marker_count_in_schema = len(schema.get('markers', []))
        actual_marker_count = self.db.markers.count_documents({})
        
        results = {
            'exists': True,
            'schema_marker_count': marker_count_in_schema,
            'actual_marker_count': actual_marker_count,
            'matches': marker_count_in_schema == actual_marker_count,
            'created_at': schema.get('created_at'),
            'version': schema.get('version')
        }
        
        status = "✅" if results['matches'] else "⚠️"
        logger.info(f"{status} Schema markers: {marker_count_in_schema}, Actual: {actual_marker_count}")
        
        return results
    
    def run_full_validation(self) -> Dict[str, Any]:
        """Runs complete validation suite"""
        logger.info("🔍 Running full migration validation...")
        
        validation_results = {
            'timestamp': datetime.utcnow(),
            'database': self.database_name,
            'collections': self.validate_collections(),
            'categories': self.validate_marker_categories(),
            'examples': self.validate_examples(),
            'query_tests': self.test_marker_queries(),
            'detection_schema': self.test_detection_schema()
        }
        
        # Overall success
        all_tests_passed = all(
            test['passed'] for test in validation_results['query_tests']
        ) and validation_results['detection_schema']['matches']
        
        validation_results['overall_success'] = all_tests_passed
        
        return validation_results
    
    def print_validation_report(self, results: Dict[str, Any]):
        """Prints detailed validation report"""
        print("\n" + "="*80)
        print("🔍 MONGODB MIGRATION VALIDATION REPORT")
        print("="*80)
        print(f"📅 Validation Time: {results['timestamp']}")
        print(f"💾 Database: {results['database']}")
        print(f"🎯 Overall Status: {'✅ PASSED' if results['overall_success'] else '❌ FAILED'}")
        
        print(f"\n📂 COLLECTIONS:")
        for collection, data in results['collections'].items():
            status = "✅" if data['exists'] else "❌"
            print(f"   {status} {collection}: {data['count']} documents")
        
        print(f"\n📊 MARKER CATEGORIES:")
        total_markers = sum(results['categories'].values())
        for category, count in results['categories'].items():
            percentage = (count / total_markers) * 100 if total_markers > 0 else 0
            print(f"   📂 {category}: {count} ({percentage:.1f}%)")
        
        print(f"\n📝 EXAMPLES:")
        ex = results['examples']
        print(f"   📊 Total Examples: {ex['total_examples']}")
        print(f"   📊 Markers with Examples: {ex['markers_with_examples']}")
        print(f"   📊 Average per Marker: {ex['average_examples_per_marker']}")
        
        print(f"\n🧪 QUERY TESTS:")
        for test in results['query_tests']:
            status = "✅" if test['passed'] else "❌"
            print(f"   {status} {test['test']}: {test['count']} (min: {test['expected_min']})")
        
        print(f"\n🔧 DETECTION SCHEMA:")
        schema = results['detection_schema']
        if schema['exists']:
            status = "✅" if schema['matches'] else "⚠️"
            print(f"   {status} Schema Validation: {schema['schema_marker_count']}/{schema['actual_marker_count']} markers")
            print(f"   📅 Created: {schema['created_at']}")
            print(f"   🏷️  Version: {schema['version']}")
        else:
            print(f"   ❌ Detection schema not found")
        
        print("="*80)
        
        if results['overall_success']:
            print("🎉 Migration validation SUCCESSFUL!")
            print("🚀 System ready for production use!")
        else:
            print("⚠️  Migration validation found issues!")
            print("🔧 Please check the logs and fix any problems.")

def main():
    parser = argparse.ArgumentParser(description='Validate MongoDB marker migration')
    parser.add_argument('--mongodb-uri', required=True, help='MongoDB Atlas connection string')
    parser.add_argument('--database', default='wordthread_markers', help='Database name')
    
    args = parser.parse_args()
    
    validator = MigrationValidator(args.mongodb_uri, args.database)
    
    if not validator.connect():
        return 1
    
    try:
        results = validator.run_full_validation()
        validator.print_validation_report(results)
        
        return 0 if results['overall_success'] else 1
        
    except Exception as e:
        logger.error(f"❌ Validation failed: {str(e)}")
        return 1
    finally:
        if validator.client:
            validator.client.close()

if __name__ == "__main__":
    exit(main())