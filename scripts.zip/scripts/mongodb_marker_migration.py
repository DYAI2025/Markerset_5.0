#!/usr/bin/env python3
"""
MongoDB Marker Migration Script für WORDthread_lab
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Importiert alle 397 Marker aus _Marker_4.6/ in MongoDB Atlas
Unterstützt: ATO_, SEM_, CLU_, MEMA_ Marker-Typen mit LeanDeep 3.4 Compliance
"""

import os
import yaml
import json
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError, BulkWriteError
import argparse
from dataclasses import dataclass

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('migration.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class MigrationStats:
    """Tracks migration statistics"""
    total_files: int = 0
    processed_files: int = 0
    successful_imports: int = 0
    failed_imports: int = 0
    duplicate_markers: int = 0
    validation_errors: int = 0
    ato_markers: int = 0
    sem_markers: int = 0
    clu_markers: int = 0
    mema_markers: int = 0
    act_markers: int = 0

class MarkerMigrationEngine:
    """Main migration engine for markers to MongoDB"""
    
    def __init__(self, marker_dir: str, mongodb_uri: str, database_name: str = "wordthread_markers"):
        self.marker_dir = Path(marker_dir)
        self.mongodb_uri = mongodb_uri
        self.database_name = database_name
        self.client: Optional[MongoClient] = None
        self.db = None
        self.collections = {}
        self.stats = MigrationStats()
        
    def connect_mongodb(self) -> bool:
        """Establishes MongoDB connection"""
        try:
            logger.info(f"🔄 Connecting to MongoDB Atlas...")
            self.client = MongoClient(self.mongodb_uri, serverSelectionTimeoutMS=30000)
            
            # Test connection
            self.client.admin.command('ping')
            self.db = self.client[self.database_name]
            
            # Initialize collections
            self.collections = {
                'markers': self.db.markers,
                'marker_examples': self.db.marker_examples,
                'detection_schemas': self.db.detection_schemas,
                'migration_log': self.db.migration_log
            }
            
            # Create indexes
            self._create_indexes()
            
            logger.info("✅ MongoDB connection successful!")
            return True
            
        except Exception as e:
            logger.error(f"❌ MongoDB connection failed: {str(e)}")
            return False
    
    def _create_indexes(self):
        """Creates necessary MongoDB indexes"""
        logger.info("🔧 Creating MongoDB indexes...")
        
        # Markers collection indexes
        self.collections['markers'].create_index("id", unique=True)
        self.collections['markers'].create_index("category")
        self.collections['markers'].create_index([("frame.signal", 1)])
        self.collections['markers'].create_index("tags")
        self.collections['markers'].create_index("updated_at")
        
        # Examples collection indexes
        self.collections['marker_examples'].create_index("marker_id")
        self.collections['marker_examples'].create_index("score")
        self.collections['marker_examples'].create_index("created_at")
        
        logger.info("✅ Indexes created successfully!")
    
    def load_and_validate_marker(self, yaml_file: Path) -> Optional[Dict[str, Any]]:
        """Loads and validates a single marker YAML file"""
        try:
            with open(yaml_file, 'r', encoding='utf-8') as f:
                marker_data = yaml.safe_load(f)
            
            if not marker_data or not isinstance(marker_data, dict):
                logger.warning(f"⚠️  Empty or invalid YAML: {yaml_file.name}")
                self.stats.validation_errors += 1
                return None
            
            # Validate required fields
            if 'id' not in marker_data:
                logger.warning(f"⚠️  Missing 'id' field: {yaml_file.name}")
                self.stats.validation_errors += 1
                return None
            
            # Determine marker category from ID prefix
            marker_id = marker_data['id']
            category = self._determine_category(marker_id)
            marker_data['category'] = category
            
            # Add metadata
            marker_data['_metadata'] = {
                'source_file': yaml_file.name,
                'imported_at': datetime.now(timezone.utc),
                'migration_version': '1.0',
                'lean_deep_version': marker_data.get('version', '3.4')
            }
            
            # Ensure required fields exist
            marker_data.setdefault('lang', 'de')
            marker_data.setdefault('tags', [])
            marker_data.setdefault('examples', [])
            
            # Count by category
            self._update_category_stats(category)
            
            return marker_data
            
        except yaml.YAMLError as e:
            logger.error(f"❌ YAML parsing error in {yaml_file.name}: {str(e)}")
            self.stats.validation_errors += 1
            return None
        except Exception as e:
            logger.error(f"❌ Error processing {yaml_file.name}: {str(e)}")
            self.stats.validation_errors += 1
            return None
    
    def _determine_category(self, marker_id: str) -> str:
        """Determines marker category from ID prefix"""
        if marker_id.startswith('ATO_'):
            return 'ATOMIC'
        elif marker_id.startswith('SEM_'):
            return 'SEMANTIC'
        elif marker_id.startswith('CLU_'):
            return 'CLUSTER'
        elif marker_id.startswith('MEMA_'):
            return 'META'
        elif marker_id.startswith('ACT_'):
            return 'ACTION'
        else:
            return 'UNKNOWN'
    
    def _update_category_stats(self, category: str):
        """Updates statistics for each category"""
        if category == 'ATOMIC':
            self.stats.ato_markers += 1
        elif category == 'SEMANTIC':
            self.stats.sem_markers += 1
        elif category == 'CLUSTER':
            self.stats.clu_markers += 1
        elif category == 'META':
            self.stats.mema_markers += 1
        elif category == 'ACTION':
            self.stats.act_markers += 1
    
    def process_examples(self, marker: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Processes marker examples into separate documents"""
        examples = []
        marker_id = marker['id']
        marker_examples = marker.get('examples', [])
        
        for idx, example_text in enumerate(marker_examples):
            if isinstance(example_text, str) and example_text.strip():
                example_doc = {
                    'marker_id': marker_id,
                    'example_id': f"{marker_id}_ex_{idx:03d}",
                    'text': example_text.strip(),
                    'language': marker.get('lang', 'de'),
                    'score': 0.8,  # Default confidence
                    'validated': False,
                    'created_at': datetime.now(timezone.utc),
                    'metadata': {
                        'source': 'marker_definition',
                        'category': marker.get('category', 'UNKNOWN')
                    }
                }
                examples.append(example_doc)
        
        return examples
    
    def migrate_all_markers(self) -> bool:
        """Main migration process for all markers"""
        logger.info(f"🚀 Starting migration of markers from {self.marker_dir}")
        
        # Get all YAML files
        yaml_files = list(self.marker_dir.glob("*.yaml"))
        self.stats.total_files = len(yaml_files)
        
        logger.info(f"📊 Found {self.stats.total_files} marker files to process")
        
        markers_batch = []
        examples_batch = []
        batch_size = 100
        
        for yaml_file in yaml_files:
            self.stats.processed_files += 1
            
            # Load and validate marker
            marker_data = self.load_and_validate_marker(yaml_file)
            if not marker_data:
                self.stats.failed_imports += 1
                continue
            
            # Process examples
            examples = self.process_examples(marker_data)
            examples_batch.extend(examples)
            
            # Remove examples from marker document (stored separately)
            if 'examples' in marker_data:
                marker_data['example_count'] = len(marker_data['examples'])
                del marker_data['examples']
            
            markers_batch.append(marker_data)
            
            # Batch insert
            if len(markers_batch) >= batch_size:
                self._insert_batch(markers_batch, examples_batch)
                markers_batch = []
                examples_batch = []
            
            if self.stats.processed_files % 50 == 0:
                logger.info(f"📊 Processed {self.stats.processed_files}/{self.stats.total_files} files...")
        
        # Insert remaining batch
        if markers_batch:
            self._insert_batch(markers_batch, examples_batch)
        
        self._create_detection_schema()
        self._log_migration()
        
        return True
    
    def _insert_batch(self, markers: List[Dict[str, Any]], examples: List[Dict[str, Any]]):
        """Inserts a batch of markers and examples"""
        try:
            # Insert markers
            if markers:
                try:
                    result = self.collections['markers'].insert_many(markers, ordered=False)
                    self.stats.successful_imports += len(result.inserted_ids)
                    logger.info(f"✅ Inserted {len(result.inserted_ids)} markers")
                except BulkWriteError as e:
                    # Handle duplicates
                    self.stats.successful_imports += len(e.details['writeErrors'])
                    for error in e.details['writeErrors']:
                        if error['code'] == 11000:  # Duplicate key error
                            self.stats.duplicate_markers += 1
                        else:
                            self.stats.failed_imports += 1
                            logger.error(f"❌ Insert error: {error['errmsg']}")
            
            # Insert examples
            if examples:
                try:
                    self.collections['marker_examples'].insert_many(examples, ordered=False)
                    logger.info(f"✅ Inserted {len(examples)} examples")
                except Exception as e:
                    logger.error(f"❌ Error inserting examples: {str(e)}")
                    
        except Exception as e:
            logger.error(f"❌ Batch insert failed: {str(e)}")
            self.stats.failed_imports += len(markers)
    
    def _create_detection_schema(self):
        """Creates a detection schema for production use"""
        logger.info("🔧 Creating detection schema...")
        
        # Get all marker IDs
        marker_ids = [doc['id'] for doc in self.collections['markers'].find({}, {'id': 1})]
        
        schema = {
            '_id': 'wordthread_production_schema',
            'name': 'WORDthread Production Detection Schema',
            'version': '3.4',
            'created_at': datetime.now(timezone.utc),
            'active': True,
            'markers': marker_ids,
            'statistics': {
                'total_markers': len(marker_ids),
                'ato_markers': self.stats.ato_markers,
                'sem_markers': self.stats.sem_markers,
                'clu_markers': self.stats.clu_markers,
                'mema_markers': self.stats.mema_markers,
                'act_markers': self.stats.act_markers
            },
            'metadata': {
                'migration_version': '1.0',
                'source_directory': str(self.marker_dir),
                'imported_at': datetime.now(timezone.utc)
            }
        }
        
        self.collections['detection_schemas'].replace_one(
            {'_id': 'wordthread_production_schema'}, 
            schema, 
            upsert=True
        )
        
        logger.info("✅ Detection schema created!")
    
    def _log_migration(self):
        """Logs migration details to database"""
        migration_record = {
            'migration_id': f"marker_migration_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'started_at': datetime.now(timezone.utc),
            'completed_at': datetime.now(timezone.utc),
            'source_directory': str(self.marker_dir),
            'statistics': {
                'total_files': self.stats.total_files,
                'processed_files': self.stats.processed_files,
                'successful_imports': self.stats.successful_imports,
                'failed_imports': self.stats.failed_imports,
                'duplicate_markers': self.stats.duplicate_markers,
                'validation_errors': self.stats.validation_errors,
                'by_category': {
                    'ato_markers': self.stats.ato_markers,
                    'sem_markers': self.stats.sem_markers,
                    'clu_markers': self.stats.clu_markers,
                    'mema_markers': self.stats.mema_markers,
                    'act_markers': self.stats.act_markers
                }
            }
        }
        
        self.collections['migration_log'].insert_one(migration_record)
    
    def print_summary(self):
        """Prints migration summary"""
        print("\n" + "="*80)
        print("🎉 MONGODB MARKER MIGRATION SUMMARY")
        print("="*80)
        print(f"📊 Total files found:      {self.stats.total_files}")
        print(f"✅ Successfully imported:   {self.stats.successful_imports}")
        print(f"❌ Failed imports:          {self.stats.failed_imports}")
        print(f"🔄 Duplicate markers:       {self.stats.duplicate_markers}")
        print(f"⚠️  Validation errors:      {self.stats.validation_errors}")
        print(f"\n📂 BY CATEGORY:")
        print(f"   🔷 ATO (Atomic):          {self.stats.ato_markers}")
        print(f"   🔶 SEM (Semantic):        {self.stats.sem_markers}")
        print(f"   🔴 CLU (Cluster):         {self.stats.clu_markers}")
        print(f"   🟣 MEMA (Meta):           {self.stats.mema_markers}")
        print(f"   🟢 ACT (Action):          {self.stats.act_markers}")
        print(f"\n🎯 Database: {self.database_name}")
        print(f"📑 Collections: markers, marker_examples, detection_schemas")
        print("="*80)
        
        # Success rate
        if self.stats.total_files > 0:
            success_rate = (self.stats.successful_imports / self.stats.total_files) * 100
            print(f"📈 Success Rate: {success_rate:.1f}%")
        
        if self.stats.failed_imports > 0:
            print(f"\n⚠️  Check migration.log for details on failed imports")

def main():
    parser = argparse.ArgumentParser(description='MongoDB Marker Migration for WORDthread_lab')
    parser.add_argument('--marker-dir', default='_Marker_4.6', help='Directory containing marker YAML files')
    parser.add_argument('--mongodb-uri', required=True, help='MongoDB Atlas connection string')
    parser.add_argument('--database', default='wordthread_markers', help='Database name')
    parser.add_argument('--force', action='store_true', help='Force migration (clear existing data)')
    
    args = parser.parse_args()
    
    # Initialize migration engine
    migration = MarkerMigrationEngine(
        marker_dir=args.marker_dir,
        mongodb_uri=args.mongodb_uri,
        database_name=args.database
    )
    
    # Connect to MongoDB
    if not migration.connect_mongodb():
        return 1
    
    # Clear existing data if forced
    if args.force:
        logger.info("🗑️  Clearing existing data (--force flag)")
        migration.collections['markers'].delete_many({})
        migration.collections['marker_examples'].delete_many({})
    
    # Run migration
    try:
        success = migration.migrate_all_markers()
        migration.print_summary()
        
        return 0 if success else 1
        
    except KeyboardInterrupt:
        logger.info("\n⏹️  Migration interrupted by user")
        return 1
    except Exception as e:
        logger.error(f"❌ Migration failed: {str(e)}")
        return 1
    finally:
        if migration.client:
            migration.client.close()

if __name__ == "__main__":
    exit(main())