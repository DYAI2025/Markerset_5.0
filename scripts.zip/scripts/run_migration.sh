#!/bin/bash
# =============================================================================
# MongoDB Marker Migration Runner für WORDthread_lab
# =============================================================================

echo "🚀 WORDthread_lab MongoDB Marker Migration"
echo "==========================================="

# Check if Python dependencies are installed
echo "🔧 Checking Python dependencies..."
python3 -c "import pymongo, yaml" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "📦 Installing required packages..."
    pip3 install pymongo pyyaml
fi

# Set paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
MARKER_DIR="$PROJECT_DIR/_Marker_4.6"

echo "📁 Project Directory: $PROJECT_DIR"
echo "📂 Marker Directory: $MARKER_DIR"
echo "📝 Found $(ls -1 "$MARKER_DIR"/*.yaml | wc -l) marker files"

# Check if marker directory exists
if [ ! -d "$MARKER_DIR" ]; then
    echo "❌ Error: Marker directory not found: $MARKER_DIR"
    exit 1
fi

# Prompt for MongoDB credentials
echo ""
echo "🔐 MongoDB Atlas Connection Setup"
echo "================================="
read -p "MongoDB Username: " MONGO_USER
read -s -p "MongoDB Password: " MONGO_PASS
echo ""
read -p "MongoDB Cluster (e.g., cluster0.xxxxx): " MONGO_CLUSTER
read -p "Database Name (default: wordthread_markers): " MONGO_DB
MONGO_DB=${MONGO_DB:-wordthread_markers}

# Build MongoDB URI
MONGO_URI="mongodb+srv://${MONGO_USER}:${MONGO_PASS}@${MONGO_CLUSTER}.mongodb.net/${MONGO_DB}?retryWrites=true&w=majority"

echo ""
echo "🔄 Starting migration..."
echo "========================"
echo "🎯 Target Database: $MONGO_DB"
echo "📊 Processing 397 markers from _Marker_4.6/"
echo ""

# Run migration with proper error handling
cd "$PROJECT_DIR"
python3 "$SCRIPT_DIR/mongodb_marker_migration.py" \
    --marker-dir "$MARKER_DIR" \
    --mongodb-uri "$MONGO_URI" \
    --database "$MONGO_DB" \
    "$@"

MIGRATION_STATUS=$?

if [ $MIGRATION_STATUS -eq 0 ]; then
    echo ""
    echo "🎉 Migration completed successfully!"
    echo "💾 Check migration.log for details"
    echo "🌐 MongoDB Collections created:"
    echo "   • markers (main marker definitions)"
    echo "   • marker_examples (separated examples)"
    echo "   • detection_schemas (production schema)"
    echo "   • migration_log (audit trail)"
else
    echo ""
    echo "❌ Migration failed with status: $MIGRATION_STATUS"
    echo "📋 Check migration.log for error details"
fi

exit $MIGRATION_STATUS