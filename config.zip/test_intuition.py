# test_intuition.py
"""
Test Suite for Intuition Package v3.3
Basic unit tests for runtime components
"""

import unittest
from unittest.mock import Mock, MagicMock
import sys
import os

# Add current directory to path for imports
sys.path.append(os.path.dirname(__file__))

from intuition_runtime import process_intuition_clu, parse, parse_targets
from uncertainty_guard import has_evidence_markers, check_evidence_requirements

class TestIntuitionRuntime(unittest.TestCase):
    
    def setUp(self):
        """Set up test fixtures"""
        self.ctx = Mock()
        self.ctx.window = Mock()
        self.ctx.telemetry = Mock()
        self.ctx.runtime = Mock()
        self.ctx.runtime.multipliers = []
        self.ctx.runtime.policies = []
        self.ctx.annotate = Mock()
        
        # Mock telemetry methods
        self.ctx.telemetry.get.return_value = 0
        self.ctx.telemetry.inc = Mock()
        self.ctx.telemetry.update_ewma.return_value = 0.6
        
        # Mock window methods
        self.ctx.window.last_n.return_value = []
        self.ctx.window.next_n.return_value = []
        
    def test_parse_activation_rule(self):
        """Test parsing of activation rules"""
        rule = "AT_LEAST 2 DISTINCT SEMs IN 5 messages"
        x, y = parse(rule)
        self.assertEqual(x, 2)
        self.assertEqual(y, 5)
        
    def test_parse_targets(self):
        """Test parsing of confirmation targets"""
        rule = "AT_LEAST 1 of [SEM_SADNESS_EXPRESSIONS, SEM_GUILT_ADMISSION] IN confirm_window"
        targets = parse_targets(rule)
        expected = {"SEM_SADNESS_EXPRESSIONS", "SEM_GUILT_ADMISSION"}
        self.assertEqual(targets, expected)
        
    def test_create_test_clu_marker(self):
        """Create a test CLU marker for testing"""
        clu = Mock()
        clu.id = "CLU_INTUITION_GRIEF"
        clu.state = "inactive"
        clu.composed_of = ["SEM_SADNESS_EXPRESSIONS", "SEM_GUILT_ADMISSION"]
        clu.activation = {"rule": "AT_LEAST 2 DISTINCT SEMs IN 5 messages"}
        clu.metadata = {
            "intuition": {
                "confirm_window": 5,
                "confirm_rule": "AT_LEAST 1 of [SEM_SADNESS_EXPRESSIONS] IN confirm_window",
                "multiplier_on_confirm": 2.0,
                "decay_window": 8
            },
            "telemetry_keys": {
                "counter_confirmed": "INT_GRIEF.confirmed",
                "counter_retracted": "INT_GRIEF.retracted", 
                "ewma_precision": "INT_GRIEF.ewma_precision"
            }
        }
        return clu

class TestUncertaintyGuard(unittest.TestCase):
    
    def test_has_evidence_markers_positive(self):
        """Test evidence detection - positive cases"""
        claim = {"text": "According to research, this is true"}
        self.assertTrue(has_evidence_markers(claim))
        
    def test_has_evidence_markers_negative(self):
        """Test evidence detection - negative cases"""
        claim = {"text": "I think this might be true"}
        self.assertFalse(has_evidence_markers(claim))
        
    def test_check_evidence_requirements_no_policy(self):
        """Test evidence check when no policy is active"""
        ctx = Mock()
        ctx.runtime.policies = []
        claim = {"text": "Some claim"}
        
        valid, message = check_evidence_requirements(ctx, claim)
        self.assertTrue(valid)
        self.assertEqual(message, "Evidence check passed")
        
    def test_check_evidence_requirements_with_policy(self):
        """Test evidence check when evidence policy is active"""
        ctx = Mock()
        ctx.runtime.policies = [{"id": "evidence_mode"}]
        claim = {"text": "Some ungrounded claim"}
        
        valid, message = check_evidence_requirements(ctx, claim)
        self.assertFalse(valid)
        self.assertIn("Evidence required", message)

class TestIntuitionIntegration(unittest.TestCase):
    """Integration tests for the complete intuition system"""
    
    def setUp(self):
        self.ctx = Mock()
        self.setup_mock_context()
        
    def setup_mock_context(self):
        """Set up comprehensive mock context"""
        self.ctx.window = Mock()
        self.ctx.telemetry = Mock()
        self.ctx.runtime = Mock()
        self.ctx.runtime.multipliers = []
        self.ctx.runtime.policies = []
        self.ctx.annotate = Mock()
        
        # Default return values
        self.ctx.telemetry.get.return_value = 5
        self.ctx.telemetry.update_ewma.return_value = 0.65
        
    def test_full_intuition_workflow(self):
        """Test complete intuition processing workflow"""
        # This would test the full flow from activation to confirmation
        # Implementation would depend on your actual context structure
        pass

if __name__ == "__main__":
    # Run specific test classes
    test_classes = [
        TestIntuitionRuntime,
        TestUncertaintyGuard, 
        TestIntuitionIntegration
    ]
    
    loader = unittest.TestLoader()
    suites = []
    for test_class in test_classes:
        suite = loader.loadTestsFromTestCase(test_class)
        suites.append(suite)
    
    combined_suite = unittest.TestSuite(suites)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # Exit with error code if tests failed
    sys.exit(0 if result.wasSuccessful() else 1)
