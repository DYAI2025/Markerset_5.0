# Intuition Package v3.3 — merge‑ready

**Cluster-Marker für dynamisches Selbstlernen und intuitive Vorhersage**

## Übersicht

Dieses Package enthält ein vollständiges Intuitions-System mit:

* **5 CLU_INTUITION Marker** (eine pro Familie)
* **Lightweight Runtime Hook** für `contextual_rescan`
* **Telemetrie-Endpunkte** mit Dashboard-Daten
* **UNCERTAINTY Guardian Policy** (optional, Evidence Mode)

Alle Blöcke folgen den Lean-Deep v3.3 Konventionen: CLU aggregiert SEM via X-of-Y Fenster; `frame:{signal,concept,pragmatics,narrative}` ist vorhanden; genau ein struktureller Block; `activation/scoring` bereitgestellt; Beispiele/Tags enthalten.

## Marker-Familien

### 🔮 CLU_INTUITION_GRIEF
- **Konzept**: Vorahnung: Trauer/Schuld/Bedauern
- **Zusammensetzung**: SEM_SADNESS_EXPRESSIONS, SEM_NOSTALGIA_REGRET, SEM_GUILT_ADMISSION
- **Pragmatik**: Fokus schärfen, biasarm
- **Aktivierung**: AT_LEAST 2 DISTINCT SEMs IN 5 messages

### ⚡ CLU_INTUITION_CONFLICT  
- **Konzept**: Vorahnung: Konflikt/Eskalation
- **Zusammensetzung**: SEM_NEGATIVE_FEEDBACK, SEM_SARCASM_IRRITATION, SEM_ESCALATION_MOVE
- **Pragmatik**: Frühwarnung, Deeskalation
- **Aktivierung**: AT_LEAST 2 DISTINCT SEMs IN 4 messages

### 🤝 CLU_INTUITION_SUPPORT
- **Konzept**: Vorahnung: Unterstützung/Bindung  
- **Zusammensetzung**: SEM_SUPPORT_VALIDATION, SEM_TRUST_SIGNALING, SEM_EMOTIONAL_SUPPORT
- **Pragmatik**: Ressourcenfokus, Verstärkung
- **Aktivierung**: AT_LEAST 2 DISTINCT SEMs IN 6 messages

### 📝 CLU_INTUITION_COMMITMENT
- **Konzept**: Vorahnung: Zusage vs. Aufschub
- **Zusammensetzung**: SEM_CLEAR_COMMITMENT, SEM_DELAYING_MOVE, SEM_PROCRASTINATION_BEHAVIOR  
- **Pragmatik**: Flow steuern, Blockaden erkennen
- **Aktivierung**: AT_LEAST 2 DISTINCT SEMs IN 5 messages

### 🤔 CLU_INTUITION_UNCERTAINTY
- **Konzept**: Vorahnung: Unsicherheit/Hedging
- **Zusammensetzung**: SEM_UNCERTAINTY_TONING, SEM_TENTATIVE_INFERENCE, SEM_PROBABILISTIC_LANGUAGE
- **Pragmatik**: Hypothesen vorsichtig testen  
- **Aktivierung**: AT_LEAST 2 DISTINCT SEMs IN 5 messages

## State Machine

```
[Schwache Signale] → provisional → confirmed (Evidenz gefunden) → Multiplier anwenden
                                → decayed (keine Evidenz) → Retracted-Counter erhöhen
```

## Adaptive Learning

Das System passt automatisch Schwellenwerte basierend auf Präzisions-Metriken an:

- **EWMA ≥ 0.70** 🟢: Aktivierungsregeln lockern, Bestätigungsziele erweitern
- **EWMA < 0.50** 🔴: Aktivierungsregeln verschärfen, auf hochvertrauenswürdige Ziele beschränken  
- **0.50-0.69** 🟡: Aktuelle Einstellungen beibehalten

## Telemetrie

Jede Familie verfolgt:
- `INT_{FAMILY}.confirmed` - Erfolgreiche Bestätigungen
- `INT_{FAMILY}.retracted` - Fehlgeschlagene Vorhersagen
- `INT_{FAMILY}.ewma_precision` - Exponentiell gewichteter gleitender Durchschnitt

## Dateien

### Marker (YAML)
- `CLU_INTUITION_GRIEF.yaml` ✅ **vorhanden**
- `CLU_INTUITION_CONFLICT.yaml` ✅ **vorhanden**  
- `CLU_INTUITION_SUPPORT.yaml` ✅ **vorhanden**
- `CLU_INTUITION_COMMITMENT.yaml` ✅ **vorhanden**
- `CLU_INTUITION_UNCERTAINTY.yaml` ✅ **vorhanden**

### Runtime-Komponenten (Python)
- `intuition_runtime.py` ✅ **hinzugefügt** - Core Processing (~70 LOC)
- `telemetry_endpoints.py` ✅ **hinzugefügt** - Flask Endpunkte für Metriken
- `uncertainty_guard.py` ✅ **hinzugefügt** - Evidence Policy Enforcement

### Dokumentation
- `INTUITION_INTEGRATION_GUIDE.md` ✅ **hinzugefügt** - Detaillierte Integration
- `README_INTUITION.md` ✅ **dieses Dokument**

## Integration

1. **Runtime Hook**: Füge `contextual_rescan_hook(ctx)` am Ende von Phase-3 hinzu
2. **Telemetrie**: Registriere Blueprint für `/telemetry/intuition` Endpunkte  
3. **Evidence Policy**: Optional für uncertainty-basierte Evidenzanforderungen

Siehe `INTUITION_INTEGRATION_GUIDE.md` für detaillierte Schritte.

## Beispiel-Dashboard JSON

```json
[
  {"family":"grief","confirmed":12,"retracted":4,"ewma":0.73,"status":"green"},
  {"family":"conflict","confirmed":9,"retracted":11,"ewma":0.45,"status":"red"},
  {"family":"support","confirmed":21,"retracted":3,"ewma":0.82,"status":"green"},
  {"family":"commit","confirmed":7,"retracted":5,"ewma":0.58,"status":"amber"},
  {"family":"uncert","confirmed":14,"retracted":6,"ewma":0.70,"status":"green"}
]
```

## Besonderheiten

- **Non-intrusive**: YAML bleibt statisch und CI-sicher; Anpassung erfolgt zur Laufzeit
- **Selbstlernend**: Automatische Schwellwert-Anpassung basierend auf Erfolgsraten
- **Telemetrie-ready**: Vollständige Metriken für Monitoring und Tuning
- **Modular**: Jede Komponente kann einzeln integriert werden

---

**Status**: ✅ Vollständig implementiert und merge-ready  
**Version**: 3.3  
**Kompatibilität**: Lean-Deep v3.3 Schema
