# LeanDeep 3.3 Configuration System Documentation

## Overview

This document describes the Enhanced Set Overrides (ESO), Primary Access Weights (PAW), and Core Bundle Manifest (CBM) system for fine-tuning LeanDeep 3.3 marker detection and scoring.

## Architecture

### Core Components

1. **Enhanced Set Overrides (ESO)** - Fine-tuning of activation/window parameters
2. **Primary Access Weights Overrides (PAW)** - Priority weights for marker aggregation
3. **Sets Overrides (SO)** - Concrete set/assignment rules and window rules
4. **Detect Registry (DR)** - Index of all detector modules
5. **Score Window/Calculations (SCR)** - Aggregation windows and decay methodology
6. **Core Bundle Manifest (CBM)** - Central manifest with version/hash/dependency tracking

### Backend Flow

```mermaid
flowchart TD
  A[POST /analyze (Text)] --> B[OrchestrationService – Context init]
  B --> C[MarkerService.initial_scan]
  C --> D[NlpService.enrich (Spark NLP)]
  D --> E[MarkerService.contextual_rescan]
  E --> F[Scoring Engine]

  subgraph Config Layer
    X1[core_bundle_manifest.yaml]
    X2[enhanced_set_overrides.yaml]
    X3[primary_access_weights_overrides.yaml]
    X4[sets_overrides.yaml]
    X5[detect_registry.json]
    X6[scr_window.json]
  end

  B -. load manifest/paths .-> X1
  C -. use detectors .-> X5
  E -. apply sets/overrides .-> X2
  F -. weights .-> X3
  F -. window/aggregation .-> X6
  E -. membership .-> X4
  F --> G[Response (Context + Scores)]
```

## Configuration Files

### 1. Enhanced Set Overrides (`enhanced_set_overrides.yaml`)

Fine-grained parameter overrides for specific marker sets:

```yaml
version: "1.0.0"
sets:
  - id: SOFT_DECLINE_TUNING
    targets: ["SEM_SOFT_DECLINE", "CLU_PROCRASTINATION_LOOP"]
    overrides:
      activation: { rule: "AT_LEAST 2 IN 4 messages" }
      window: { messages: 12 }
      scoring: { base: 1.9, weight: 1.25, decay: 0.01 }
```

### 2. Primary Access Weights (`primary_access_weights_overrides.yaml`)

Priority weights for marker aggregation with optional context filters:

```yaml
version: "1.0.0"
weights:
  - target_id: "SEM_SOFT_DECLINE"
    weight: 1.2
    context: { lang: "de", channel: "chat" }
```

### 3. Sets Overrides (`sets_overrides.yaml`)

Concrete groupings of markers with window and activation rules:

```yaml
version: "1.0.0"
groups:
  - name: "SOFT_DECLINE_GROUP"
    includes: ["ATO_DELAY_PHRASE", "ATO_UNCERTAINTY_PHRASE", "SEM_SOFT_DECLINE"]
    window: { messages: 10 }
    activation: { rule: "ANY 2 IN 3 messages" }
```

### 4. Detect Registry (`detect_registry.json`)

Index of all detector modules:

```json
[
  {
    "id": "DETECT_FIRST_PERSON_PRONOUN",
    "description": "German first person pronoun detection",
    "module": "regex",
    "file_path": "detectors/regex/first_person_pronoun.py",
    "fires_marker": "ATO_FIRST_PERSON_PRONOUN",
    "schema_version": "LD-3.3"
  }
]
```

### 5. Score Window (`scr_window.json`)

Aggregation windows and decay methodology:

```json
{
  "target_markers": ["SEM_SOFT_DECLINE", "CLU_PROCRASTINATION_LOOP"],
  "window": { "messages": 30 },
  "aggregation": { "method": "sum", "decay": 0.02 }
}
```

### 6. Core Bundle Manifest (`core_bundle_manifest.yaml`)

Central manifest with version/hash/dependency tracking:

```yaml
version: "1.0.0"
artifacts:
  - kind: "enhanced_set_overrides"
    path: "config/enhanced_set_overrides.yaml"
    version: "1.0.0"
    hash: "sha256:..."
    depends_on: ["sets_overrides", "detect_registry"]
```

## Calculation Formula

### Primary Formula (per message):
```
partial = weight(target_id, context) * marker_score(event)
```

### Aggregation in Window:
```
score_window = Σ partial * e^(-decay * Δt)  (for method=sum)
```

Where:
- `weight(...)` comes from Primary Access Weights Overrides (default 1.0)
- `marker_score(event)` comes from marker recognition (ATO/SEM/CLU)
- Window/Decay/Method from `scr_window.json` or overrides from `enhanced_set_overrides.yaml`

## Contextual Re-Scan Logic

1. **Initial Scan**: ATO markers detected using detect_registry
2. **NLP Enrichment**: Sentiment, NER, negation analysis
3. **Contextual Re-Scan**: SEM/CLU/MEMA evaluated after enrichment
4. **Scoring/Aggregation**: Applied with weights and window configurations

## CI/QA & Linting

- JSON Schema validation for all artifacts (Draft-07)
- SEM 3.3 composition check (pre-commit hook)
- YAML lint / JSON schema / Markdown lint
- Release branch & changelog management

## File Structure

```
/bundle/
  config/
    enhanced_set_overrides.yaml
    primary_access_weights_overrides.yaml
    sets_overrides.yaml
    detect_registry.json
    scr_window.json
  schemas/
    config/
      enhanced_set_overrides.schema.json
      primary_access_weights_overrides.schema.json
      core_bundle_manifest.schema.json
      sets_overrides.schema.json
      detect_registry.schema.json
      scr_window.schema.json
  core_bundle_manifest.yaml
```

## Maintenance

### Detect Registry Maintenance
- Entries must contain: `id`, `module`, `file_path`, `fires_marker`, `schema_version`
- `fires_marker` follows ATO/SEM/CLU/MEMA pattern
- Version changes tracked in `last_updated`
- CI checks file path existence

### Schema Validation
All configuration files are validated against their respective JSON Schema (Draft-07) definitions.

### Dependency Management
The Core Bundle Manifest tracks dependencies between configuration files, ensuring proper load order and consistency checks.

## Example Usage

The system enables:
1. **Audio-Text Bridge Patterns**: Combining prosodic and linguistic markers
2. **Contextual Weighting**: Different weights for different languages/channels
3. **Dynamic Window Adjustment**: Fine-tuning temporal aggregation windows
4. **Modular Detector System**: Easy addition of new detection modules
5. **Version-Controlled Configuration**: Hash-based integrity checking

This configuration system provides the flexibility needed for advanced personality analysis while maintaining strict schema compliance and dependency tracking.
