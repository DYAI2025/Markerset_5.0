# Intuition Package v3.3 - Integration Guide

## Overview
This package contains the complete Intuition system with CLU markers, runtime hooks, telemetry, and adaptive learning capabilities.

## Files in this Package

### Marker Files (YAML)
- `CLU_INTUITION_GRIEF.yaml` - Grief/guilt/regret detection
- `CLU_INTUITION_CONFLICT.yaml` - Conflict/escalation early warning  
- `CLU_INTUITION_SUPPORT.yaml` - Support/bonding signals
- `CLU_INTUITION_COMMITMENT.yaml` - Commitment vs procrastination
- `CLU_INTUITION_UNCERTAINTY.yaml` - Uncertainty/hedging patterns

### Runtime Components (Python)
- `intuition_runtime.py` - Core processing logic (~70 LOC)
- `telemetry_endpoints.py` - Flask endpoints for metrics
- `uncertainty_guard.py` - Evidence policy enforcement

## Integration Steps

### 1. Runtime Hook Integration
Add this to your Phase-3 `contextual_rescan`:

```python
from .intuition_runtime import contextual_rescan_hook

def contextual_rescan(ctx):
    # ... your existing contextual processing ...
    
    # Add at the end:
    contextual_rescan_hook(ctx)
```

### 2. Telemetry Endpoints
Register the blueprint in your Flask app:

```python
from .routes.telemetry import bp as telemetry_bp
app.register_blueprint(telemetry_bp)
```

Access endpoints:
- `GET /telemetry/intuition` - All families overview
- `GET /telemetry/intuition/{family}` - Specific family details
- `GET /telemetry/intuition/dashboard` - UI dashboard data

### 3. Evidence Policy (Optional)
To enable uncertainty-based evidence requirements:

```python
# In your claim processing:
from .uncertainty_guard import check_evidence_requirements

def process_claim(ctx, claim):
    valid, message = check_evidence_requirements(ctx, claim)
    if not valid:
        # Handle evidence requirement
        pass
```

## Marker Schema

All CLU_INTUITION markers follow Lean-Deep v3.3 conventions:

```yaml
id: CLU_INTUITION_*
schema_version: "LD-3.3"
frame:
  signal: ["intuition","weak-aggregation"]
  concept: "Vorahnung: [description]"
  pragmatics: "[focus area]"
  narrative: "hypothesis"
tags: [intuition, *, learning]
composed_of: [SEM_*, SEM_*, SEM_*]
activation: { rule: "AT_LEAST X DISTINCT SEMs IN Y messages" }
scoring: { base: 0.5, weight: 1.0 }
metadata:
  intuition:
    state: "provisional"
    confirm_window: N
    confirm_rule: "AT_LEAST 1 of [SEM_*] IN confirm_window"
    multiplier_on_confirm: X.X
    decay_window: N
```

## Adaptive Learning

The system automatically adjusts thresholds based on precision metrics:

- **EWMA ≥ 0.70**: Loosen activation rules, broaden confirmation targets
- **EWMA < 0.50**: Tighten activation rules, narrow to high-confidence targets
- **0.50-0.69**: Hold current settings

## State Machine

```
provisional → confirmed (evidence found) → apply multiplier
           → decayed (no evidence) → increment retracted counter
```

## Telemetry Keys

Each family tracks:
- `INT_{FAMILY}.confirmed` - Successful confirmations
- `INT_{FAMILY}.retracted` - Failed predictions (decayed)
- `INT_{FAMILY}.ewma_precision` - Exponential weighted moving average

## Dependencies

Replace these placeholder functions with your actual implementations:
- `ctx.window.last_n(n)` - Get last N marker matches
- `ctx.window.next_n(n)` - Get next N marker matches  
- `ctx.telemetry.get(key, default)` - Get telemetry value
- `ctx.telemetry.inc(key)` - Increment counter
- `ctx.telemetry.update_ewma(key, value, alpha)` - Update EWMA
- `ctx.annotate(marker, note)` - Add annotation
- `ctx.runtime.multipliers` - Apply confidence multipliers
- `ctx.runtime.policies` - Active policies list

## Notes

- YAML markers remain static and CI-safe
- All adaptation happens at runtime
- Counters are monotonic for reliable metrics
- Use multiplier TTLs to prevent lasting bias
- Mine frequent ATO pairs from confirmed windows for new SEM candidates

## Example Usage

```python
# During processing
for marker in ctx.active_markers:
    if 'intuition' in marker.tags:
        process_intuition_clu(ctx, marker)

# Check telemetry
precision = ctx.telemetry.get("INT_GRIEF.ewma_precision", 0.5)
if precision >= 0.70:
    # High confidence - system performing well
    pass
```
