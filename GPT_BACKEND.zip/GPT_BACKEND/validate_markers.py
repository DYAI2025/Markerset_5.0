#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_markers.py: Marker-YAML Validierung
- Überprüft alle YAML-Dateien in einem Ordner (Standard: Stage3.3)
- Testet Regex-Patterns auf Gültigkeit
- Überprüft Pflichtfelder
- Validiert Namespace-Korrektheit (ATO vs SEM)
"""

import os, re, yaml, glob, argparse
from pathlib import Path

def load_yamls(folder):
    """Lädt alle .yaml/.yml Dateien aus einem Ordner"""
    results = []
    patterns = ['*.yaml', '*.yml']
    for pattern in patterns:
        for path in glob.glob(os.path.join(folder, pattern)):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                    results.append({"path": path, "data": data, "filename": os.path.basename(path)})
            except yaml.YAMLError as e:
                print(f"[ERROR] YAML Parse-Fehler in {path}: {e}")
            except Exception as e:
                print(f"[ERROR] Allgemeiner Fehler beim Laden von {path}: {e}")
    return results

def validate_required_fields(data, filepath):
    """Überprüft Pflichtfelder"""
    errors = []
    required = ['id', 'namespace', 'description', 'patterns', 'examples']
    
    for field in required:
        if field not in data:
            errors.append(f"Fehlendes Pflichtfeld: {field}")
    
    # Spezialprüfungen
    if 'patterns' in data:
        if not isinstance(data['patterns'], list) or len(data['patterns']) == 0:
            errors.append("'patterns' muss eine nicht-leere Liste sein")
        else:
            for i, pattern in enumerate(data['patterns']):
                if not isinstance(pattern, str) or not pattern.strip():
                    errors.append(f"Pattern {i} ist leer oder kein String")
    
    if 'examples' in data:
        if not isinstance(data['examples'], list) or len(data['examples']) == 0:
            errors.append("'examples' muss eine nicht-leere Liste sein")
    
    return errors

def validate_regex_patterns(patterns):
    """Testet Regex-Patterns auf Gültigkeit"""
    errors = []
    for i, pattern in enumerate(patterns):
        try:
            re.compile(pattern)
        except re.error as e:
            errors.append(f"Ungültiges Regex-Pattern {i}: {pattern} → {e}")
    return errors

def validate_namespace(data, filepath):
    """Überprüft Namespace-Konsistenz"""
    errors = []
    filename = os.path.basename(filepath)
    namespace = data.get('namespace', '')
    marker_id = data.get('id', '')
    
    # Namespace muss ATO oder SEM sein
    if namespace not in ['ATO', 'SEM']:
        errors.append(f"Namespace muss 'ATO' oder 'SEM' sein, gefunden: '{namespace}'")
    
    # ID sollte mit Namespace beginnen
    if marker_id and not marker_id.startswith(namespace + '_'):
        errors.append(f"ID '{marker_id}' sollte mit '{namespace}_' beginnen")
    
    # Dateiname sollte ID enthalten oder ähnlich sein
    base_filename = filename.replace('.yaml', '').replace('.yml', '')
    if marker_id and marker_id.lower() not in base_filename.lower():
        errors.append(f"Dateiname '{filename}' sollte ID '{marker_id}' enthalten")
    
    return errors

def validate_examples_against_patterns(data):
    """Prüft ob Beispiele zu den Patterns passen"""
    errors = []
    patterns = data.get('patterns', [])
    examples = data.get('examples', [])
    
    if not patterns or not examples:
        return errors
    
    # Kompiliere alle Patterns
    compiled_patterns = []
    for pattern in patterns:
        try:
            compiled_patterns.append(re.compile(pattern, re.IGNORECASE))
        except re.error:
            continue  # Bereits in validate_regex_patterns geprüft
    
    if not compiled_patterns:
        return errors
    
    # Prüfe jedes Beispiel
    for i, example in enumerate(examples):
        if not isinstance(example, str):
            continue
            
        matched = False
        for pattern in compiled_patterns:
            if pattern.search(example):
                matched = True
                break
        
        if not matched:
            errors.append(f"Beispiel {i} '{example}' matcht keines der Patterns")
    
    return errors

def validate_single_file(filepath, data):
    """Validiert eine einzelne YAML-Datei"""
    errors = []
    
    # Pflichtfelder prüfen
    errors.extend(validate_required_fields(data, filepath))
    
    # Regex-Patterns prüfen
    patterns = data.get('patterns', [])
    if patterns:
        errors.extend(validate_regex_patterns(patterns))
    
    # Namespace prüfen
    errors.extend(validate_namespace(data, filepath))
    
    # Beispiele gegen Patterns prüfen
    errors.extend(validate_examples_against_patterns(data))
    
    return errors

def generate_report(results):
    """Generiert einen Validierungsbericht"""
    total_files = len(results)
    valid_files = len([r for r in results if not r['errors']])
    error_files = total_files - valid_files
    
    print(f"\n{'='*60}")
    print(f"MARKER VALIDATION REPORT")
    print(f"{'='*60}")
    print(f"Gesamte Dateien: {total_files}")
    print(f"Gültige Dateien: {valid_files}")
    print(f"Fehlerhafte Dateien: {error_files}")
    print(f"{'='*60}")
    
    if error_files > 0:
        print(f"\nFEHLER DETAILS:")
        print(f"{'-'*60}")
        for result in results:
            if result['errors']:
                print(f"\n📁 {result['filename']}")
                for error in result['errors']:
                    print(f"  ❌ {error}")
    
    if valid_files > 0:
        print(f"\n✅ GÜLTIGE DATEIEN:")
        print(f"{'-'*30}")
        for result in results:
            if not result['errors']:
                data = result['data']
                namespace = data.get('namespace', 'UNKNOWN')
                marker_id = data.get('id', 'NO_ID')
                pattern_count = len(data.get('patterns', []))
                example_count = len(data.get('examples', []))
                print(f"  {namespace:3} | {marker_id:30} | {pattern_count}P/{example_count}E | {result['filename']}")
    
    print(f"\n{'='*60}")
    return error_files == 0

def main():
    parser = argparse.ArgumentParser(description="Validiert YAML Marker-Dateien")
    parser.add_argument('--folder', default='Stage3.3', 
                       help="Ordner mit YAML-Dateien (Standard: Stage3.3)")
    parser.add_argument('--verbose', action='store_true',
                       help="Ausführliche Ausgabe")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.folder):
        print(f"[ERROR] Ordner '{args.folder}' existiert nicht")
        return 1
    
    # Lade alle YAML-Dateien
    yaml_files = load_yamls(args.folder)
    
    if not yaml_files:
        print(f"[ERROR] Keine YAML-Dateien in '{args.folder}' gefunden")
        return 1
    
    print(f"[INFO] {len(yaml_files)} YAML-Dateien gefunden in '{args.folder}'")
    
    # Validiere jede Datei
    results = []
    for yaml_file in yaml_files:
        errors = validate_single_file(yaml_file['path'], yaml_file['data'])
        results.append({
            'filename': yaml_file['filename'],
            'path': yaml_file['path'],
            'data': yaml_file['data'],
            'errors': errors
        })
        
        if args.verbose and errors:
            print(f"\n[VALIDATING] {yaml_file['filename']}")
            for error in errors:
                print(f"  ❌ {error}")
    
    # Generiere Bericht
    all_valid = generate_report(results)
    
    return 0 if all_valid else 1

if __name__ == '__main__':
    exit(main())
