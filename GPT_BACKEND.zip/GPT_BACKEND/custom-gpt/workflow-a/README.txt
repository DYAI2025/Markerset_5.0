Verwendung im Custom GPT:
1) Lade `common/schema.example.json` als Knowledge hoch (oder nimm dein eigenes Schema).
2) Setze `SYSTEM_PROMPT.md` als System-Anweisung.
3) Lade ein ZIP mit `chunk_###.json` (mit führenden Nullen).
4) Befehle:
   - "phase detect" → grober Index (optional)
   - "phase micro"  → pro Chunk puffernde Micro-Outputs
   - "phase mid render=html" → RENDER_MID.html mit JSON inline erzeugen
   - "phase final render=html" → RENDER_FINAL.html mit JSON inline erzeugen
Hinweis: Der GPT soll die Platzhalter `/*__LEGEND__*/`, `/*__VISUALS__*/`, `/*__SUMMARY__*/` im Template durch inline-JSON ersetzen.
