Verwendung:
1) Lade dein `schema.json` + optional `weights.json` hoch.
2) Setze `SYSTEM_PROMPT.md` als System-Anweisung.
3) ZIP mit `chunk_###.json` hochladen.
4) micro → mid → final wie in Workflow A; final rendert `RENDER_FINAL.html` mit zusätzlichen
   costLine/regimeBand/polarisation/sankey Feldern.
