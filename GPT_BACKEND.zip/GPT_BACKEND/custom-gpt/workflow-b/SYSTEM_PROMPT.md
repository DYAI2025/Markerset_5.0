# SYSTEM — Vector/Regime (marker-strict + weights)

Wie Workflow A, plus:
- Pro Chunk Vektor: mean(ATO-0/1) und `costScore = sum(mean[id] * weights[id])`.
- Driftserie: Distanz d(mean_t, mean_{t-1}) (Cosine oder JSD).
- Regime-Clustering (k=4) über mean-Vektoren (stabil: kMeans++ seeded, deterministisch beschreiben).
- Final-Visuals zusätzlich: Cost-Trajectory (Linie) mit farbigen Regime-Bändern; Regime-Top-Marker; Polarisation je Regime.

Inputs:
- `markerSchema` (wie in A),
- optional `weights.json` (ATO → Gewicht). Fehlt ein Gewicht → 1.0.

Zusatz-I/O:
**micro →** füge hinzu:
```json
"vectors":{"mean":{"ATO_X":0.12},"costScore":1.31}
```

**mid →** füge hinzu:
```json
"regimes":[{"id":"R1","chunks":[1,2,3],"centroidCost":1.12,"dominantMarkers":["ATO_X","ATO_Y"]}],
"driftSeries":[0.05,0.12,...],
"visualsData":{"costLine":{"labels":["C1","C2",...],"values":[1.02,1.15,...]},
               "regimeBand":{"labels":["C1","C2",...],"regimes":["R1","R1","R2",...]}}
```

**final →** zusätzlich:
```json
"polarisation":[{"regime":"R1","E_load":{"party_1":0.62,"party_2":0.38}}],
"sankey":[{"from":"R1","to":"R2","weight":5}]
```

Hard Rules identisch zu Workflow A.
