#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_schema_from_yaml.py: Automatischer Schema-Builder aus YAML-Markern
- Lädt alle YAML-Dateien aus einem Ordner
- Erstellt JSON-Schema im detect_quick.py Format
- Integriert Konfiguration aus sets_config.json und weights.json
"""

import os, json, glob, argparse
from pathlib import Path

def load_yamls(folder):
    """Lädt alle YAML-Dateien (vereinfachte Version ohne yaml-import)"""
    results = []
    for yaml_path in glob.glob(os.path.join(folder, "*.yaml")):
        try:
            # Primitive YAML-Parsing für unsere Marker-Struktur
            marker_data = parse_simple_yaml(yaml_path)
            if marker_data:
                results.append(marker_data)
        except Exception as e:
            print(f"[WARN] Fehler beim Parsen von {yaml_path}: {e}")
    return results

def parse_simple_yaml(filepath):
    """Einfacher YAML-Parser für unsere Marker-Struktur"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    data = {}
    current_list = None
    
    for line in content.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
            
        if ':' in line and not line.startswith('-'):
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            
            if key in ['patterns', 'examples']:
                current_list = key
                data[key] = []
            else:
                data[key] = value
                current_list = None
        
        elif line.startswith('-') and current_list:
            item = line[1:].strip()
            if item.startswith('"') and item.endswith('"'):
                item = item[1:-1]
            elif item.startswith("'") and item.endswith("'"):
                item = item[1:-1]
            data[current_list].append(item)
    
    return data if 'id' in data else None

def load_config_file(path, default=None):
    """Lädt JSON-Konfigurationsdatei mit Fallback"""
    if not os.path.exists(path):
        print(f"[WARN] {path} nicht gefunden, verwende Default")
        return default or {}
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"[ERROR] Fehler beim Laden von {path}: {e}")
        return default or {}

def build_schema(yaml_data, sets_config=None, weights_config=None):
    """Erstellt JSON-Schema aus YAML-Daten"""
    schema = {"ATO": [], "SEM": []}
    
    # Sortiere nach Namespace
    for marker in yaml_data:
        namespace = marker.get('namespace', 'ATO')
        if namespace not in schema:
            schema[namespace] = []
        
        # Nimm erstes Pattern (vereinfacht)
        patterns = marker.get('patterns', [])
        if not patterns:
            print(f"[WARN] Kein Pattern in Marker {marker.get('id', 'UNKNOWN')}")
            continue
        
        schema_entry = {
            "id": marker.get('id', 'UNKNOWN'),
            "pattern": patterns[0]  # Erstes Pattern verwenden
        }
        
        schema[namespace].append(schema_entry)
    
    # Füge Metriken hinzu
    if sets_config:
        schema["metrics"] = {"sets": sets_config}
    
    if weights_config:
        if "metrics" not in schema:
            schema["metrics"] = {}
        schema["metrics"]["weights"] = weights_config
    
    return schema

def main():
    parser = argparse.ArgumentParser(description="Baut JSON-Schema aus YAML-Markern")
    parser.add_argument('--yaml-folder', default='Stage3.3', 
                       help="Ordner mit YAML-Markern")
    parser.add_argument('--sets-config', default='sets_config.json',
                       help="Pfad zu sets_config.json")
    parser.add_argument('--weights-config', default='weights.json',
                       help="Pfad zu weights.json")
    parser.add_argument('--output', default='generated_schema.json',
                       help="Output-Datei für Schema")
    
    args = parser.parse_args()
    
    # Lade YAML-Marker
    if not os.path.exists(args.yaml_folder):
        print(f"[ERROR] YAML-Ordner '{args.yaml_folder}' existiert nicht")
        return 1
    
    print(f"[INFO] Lade YAML-Marker aus '{args.yaml_folder}'")
    yaml_data = load_yamls(args.yaml_folder)
    
    if not yaml_data:
        print(f"[ERROR] Keine gültigen YAML-Marker gefunden")
        return 1
    
    print(f"[INFO] {len(yaml_data)} Marker geladen")
    
    # Lade Konfigurationsdateien
    sets_config = load_config_file(args.sets_config, {
        "E": ["ATO_TRUST_DEFICIT_STATEMENT", "ATO_ACCUSATION_OF_CONTROL", "ATO_DEFENSIVE_REBUTTAL"],
        "D": ["ATO_DEESCALATION_OFFER", "ATO_APOLOGY_DE", "SEM_VALIDATION_OF_FEELING"]
    })
    
    weights_config = load_config_file(args.weights_config, {
        "escalation_weight": 1.2,
        "deescalation_weight": 0.8
    })
    
    # Erstelle Schema
    schema = build_schema(yaml_data, sets_config, weights_config)
    
    # Statistiken
    ato_count = len(schema.get('ATO', []))
    sem_count = len(schema.get('SEM', []))
    print(f"[INFO] Schema erstellt: {ato_count} ATO-Marker, {sem_count} SEM-Marker")
    
    # Speichere Schema
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(schema, f, ensure_ascii=False, indent=2)
    
    print(f"[OK] Schema gespeichert in '{args.output}'")
    
    # Zeige Vorschau
    print(f"\n[PREVIEW] Schema-Struktur:")
    for namespace, markers in schema.items():
        if namespace == "metrics":
            continue
        print(f"  {namespace}: {len(markers)} Marker")
        for marker in markers[:3]:  # Erste 3 zeigen
            print(f"    - {marker['id']}")
        if len(markers) > 3:
            print(f"    ... und {len(markers)-3} weitere")
    
    return 0

if __name__ == '__main__':
    exit(main())
