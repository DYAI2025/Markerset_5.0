#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, re, json, glob, zipfile, argparse
from datetime import datetime

# ---- Fallback-Schema (falls --schema nicht übergeben wird) ----
SCHEMA_DEFAULT = json.loads(r'''{
  "ATO": [
    { "id": "ATO_TRUST_DEFICIT_STATEMENT", "pattern": "(?i)\\bmisstrau\\w*\\b|\\bbeweis\\w*\\b|\\b(im|absichtlich)\\s+unklar(en)?\\b|\\bverheimlich\\w*\\b|\\bhinter\\s+meinem\\s+rücken\\b|\\b(etwas|vieles)\\s+verschweig\\w*\\b|\\bich\\s+werde\\s+nicht\\s+einbezogen\\b" },
    { "id": "ATO_DEFENSIVE_REBUTTAL", "pattern": "(?i)\\b(stimmt|das)\\s+nicht\\b|\\b(ich|das)\\s+habe\\s+.+\\s+nicht\\b|\\bnie\\s+getan\\b|\\bdu\\s+interpretierst\\s+das\\s+falsch\\b|\\bdu\\s+legst\\s+mir\\s+worte\\s+in\\s+den\\s+mund\\b|\\bentspricht\\s+nicht\\s+der\\s+wahrheit\\b" },
    { "id": "ATO_REQUEST_TRANSPARENCY", "pattern": "(?i)\\btranspar(en[tz])?\\b|\\behrlich(keit)?\\b|\\boffen(heit)?\\b|\\bklarheit\\b|\\berklär\\w*\\b|\\b(ich|wir)\\s+möchten?\\s+versteh\\w*\\b|\\bzuhör\\w*\\b|\\boffenleg\\w*\\b" },
    { "id": "ATO_DEESCALATION_OFFER", "pattern": "(?i)\\bohne\\s+vorwurf\\b|\\bohne\\s+anklage\\b|\\bbereit\\s+zuzuhör\\w*\\b|\\blass\\s+uns\\s+ruhig\\s+sprech\\w*\\b|\\b(ok|oki|okay)\\b|\\bich\\s+möchte\\s+versteh\\w*\\b|\\bwir\\s+kriegen\\s+das\\s+hin\\b|\\blass\\s+uns\\s+sachlich\\s+bleib\\w*\\b" },
    { "id": "ATO_APOLOGY_DE", "pattern": "(?i)\\bsorry\\b|\\bentschuldig\\w*\\b|\\btut\\s+mir\\s+leid\\b|\\bmein(e|en)?\\s+fehler\\b|\\bdafür\\s+übernehme\\s+ich\\s+die\\s+verantwortung\\b" },
    { "id": "ATO_TOPIC_SWITCH_TECH", "pattern": "(?i)\\bopen.?air\\b|\\bkino\\b|\\bfilm\\b|\\b(app|deploy(?:ment)?|release|framework)\\b|\\bwebseite\\b|\\bseite\\b|\\bgithub\\b|\\bnode\\.?js\\b|\\binstallier\\w*\\b|\\bbuild\\b|\\breleaseparty\\b|\\bclaude\\b" },
    { "id": "ATO_BOUNDARY_SET", "pattern": "(?i)\\bkontakt\\s+minimier\\w*\\b|\\bkontaktabbruch\\b|\\bwerde\\s+(dir\\s+)?nicht\\s+mehr?\\s+antworten\\b|\\bkein(en)?\\s+kontakt\\b|\\brespektier(e)?\\s+meine\\s+grenz\\w*\\b|\\bich\\s+ziehe\\s+eine\\s+klare\\s+grenze\\b" },
    { "id": "ATO_ACCUSATION_OF_CONTROL", "pattern": "(?i)\\bkontrollier\\w*\\b|\\bkontrollzwang\\b|\\bversuchst?\\s+.*\\s+zu\\s+kontrollier\\w*\\b|\\b(manipulier\\w*|manipulation)\\b|\\bbevormund\\w*\\b|\\bdu\\s+verunsicherst\\s+mich\\s+absichtlich\\b" },
    { "id": "ATO_VULNERABILITY", "pattern": "(?i)\\bich\\s+bin\\s+(verletzlich|angreifbar|unsicher)\\b|\\bes\\s+verunsichert\\s+mich\\b|\\bich\\s+hab(e)?\\s+angst\\b|\\bich\\s+bin\\s+überfordert\\b" },
    { "id": "ATO_STAY_IN_EMOTION", "pattern": "(?i)\\b(lass|lassen)\\s+uns\\s+bei\\s+(dem|der)\\s+(gefühl|emotion|thema)\\s+bleiben\\b|\\bkein\\s+themenwechsel\\b|\\bich\\s+möchte\\s+im\\s+thema\\s+bleiben\\b" },
    { "id": "ATO_VALIDATE_AND_BOUNDARY", "pattern": "(?i)\\bich\\s+verstehe\\s+dich\\b.*\\b(und|aber)\\b.*\\b(meine\\s+grenze|ich\\s+brauche\\s+abstand)\\b|\\bich\\s+höre\\s+dich\\b.*\\b(und|aber)\\b.*\\b(keine\\s+kraft|zu\\s+viel)\\b|\\bes\\s+tut\\s+mir\\s+leid\\b.*\\b(und|aber)\\b.*\\b(ich\\s+ziehe\\s+eine\\s+grenze)\\b" },
    { "id": "ATO_STATE_IMPACT", "pattern": "(?i)\\b(es|das)\\s*(macht|ließ)\\s*mich\\s+\\w+\\b|\\b(es)\\s*hat\\s*mich\\s+(verletzt|verunsichert|gefreut)\\b|\\b(dadurch|damit)\\s+bin\\s+ich\\s+\\w+\\b" },
    { "id": "ATO_POSITIVE_REGARD", "pattern": "(?i)\\b(ich\\s+denke|rede)\\s+gut\\s+von\\s+dir\\b|\\b(ich\\s+halte\\s+viel\\s+von\\s+dir)\\b|\\b(ich\\s+schätze\\s+dich)\\b|\\b(ich\\s+traue\\s+dir\\s+gutes\\s+zu)\\b" },
    { "id": "ATO_PROOF_SEEKING_BEHAVIOR", "pattern": "(?i)\\b(beweis(e)?\\s+suchen|etwas\\s+finden\\s+wollen)\\b|\\b(nach\\s+belegen\\s+schauen)\\b|\\b(in\\s+(mein|dein)\\s+handy\\s+schau\\w*)\\b|\\b(ich\\s+will\\s+etwas\\s+bestätigt\\s+sehen)\\b" },
    { "id": "ATO_SURVEILLANCE_CHECK", "pattern": "(?i)\\b(handy|telefon|chat|account)\\s*(prüfen|checken|durchsuchen)\\b|\\b(nachrichten)\\s*(lesen|kontrollieren)\\b|\\b(in\\s+(mein|dein)\\s+handy\\s+schau\\w*)\\b" },
    { "id": "ATO_SUPERLATIVE_PHRASE", "pattern": "(?i)\\b(immer|nie|ständig|andauernd|überhaupt nicht|gar nicht|nie wieder|immer nur|immer wieder)\\b" }
  ],
  "SEM": [
    { "id": "SEM_VALIDATION_OF_FEELING", "pattern": "(?i)\\b(das|dein|euer)\\s*(gefühl|unsicherheit|verletzung)\\s*(kommt)\\s*(an|bei mir an)\\b|\\bich\\s*(sehe|verstehe|erkenne)\\s*(dein|euer)\\s*(gefühl|schmerz|angst)\\b|\\b(tut\\s+mir\\s+leid|ich\\s+weiß,\\s+dass\\s+das\\s+wehtut)\\b|\\b(lass\\s+uns\\s+schauen|wir\\s+schauen)\\s*,?\\s*(was|wie)\\s+dir\\s*(hilft|guttut)\\b" },
    { "id": "SEM_I_STATEMENT", "pattern": "(?i)\\bich\\s+fühle\\s+mich\\s+\\w+\\b|\\bich\\s+brauche\\s+\\w+\\b|\\bich\\s+bitte\\s+dich\\s+um\\s+\\w+\\b|\\bich\\s+bin\\s+unsicher\\b|\\bmir\\s+fehlt\\s+(klarheit|sicherheit)\\b" },
    { "id": "SEM_SHARED_GOAL_FRAMING", "pattern": "(?i)\\bunser\\s+(gemeinsames|gleiches)\\s+ziel\\b|\\bwir\\s+stecken\\s+fest\\b|\\bkleinster\\s+schritt\\b|\\blass\\s+uns\\s+(\\w+\\s+)?zusammen\\b|\\bwir\\s+wollen\\s+beide\\b" },
    { "id": "SEM_COMMITMENT_REQUEST", "pattern": "(?i)\\b(absprache|vereinbarung|abmachung)\\b|\\b(verbindlich(keit)?|verlässlich(keit)?)\\b|\\b(wenn\\s+wir\\s+uns\\s+trennen)\\s+und\\s+wieder\\s+daten\\b|\\b(sag(en)?\\s+wir\\s+es\\s+einander)\\b" },
    { "id": "SEM_CONDITIONALITY_FRAME", "pattern": "(?i)\\bnur\\s+wenn\\b|\\b(dann|ansonsten)\\s+(kann|werde|mache)\\b|\\b(unter\\s+diesen\\s+bedingungen)\\b|\\b(erst\\s+wenn)\\b" }
  ],
  "metrics": { "sets": { "E": ["ATO_TRUST_DEFICIT_STATEMENT","ATO_ACCUSATION_OF_CONTROL","ATO_DEFENSIVE_REBUTTAL","ATO_PROOF_SEEKING_BEHAVIOR","ATO_SURVEILLANCE_CHECK","ATO_SUPERLATIVE_PHRASE"], "D": ["ATO_DEESCALATION_OFFER","ATO_APOLOGY_DE","ATO_TOPIC_SWITCH_TECH","ATO_REQUEST_TRANSPARENCY","ATO_VULNERABILITY","ATO_STAY_IN_EMOTION","ATO_VALIDATE_AND_BOUNDARY","ATO_STATE_IMPACT","ATO_POSITIVE_REGARD","SEM_VALIDATION_OF_FEELING","SEM_I_STATEMENT","SEM_SHARED_GOAL_FRAMING"] } }
}''')

def load_schema(path):
    if not path:
        return SCHEMA_DEFAULT
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def iter_chunks(src):
    if os.path.isdir(src):
        files = sorted(glob.glob(os.path.join(src, '*.json')))
        for p in files:
            with open(p, 'r', encoding='utf-8') as f:
                yield os.path.basename(p), json.load(f)
    elif zipfile.is_zipfile(src):
        with zipfile.ZipFile(src) as z:
            names = sorted([n for n in z.namelist() if n.lower().endswith('.json')])
            for n in names:
                with z.open(n) as f:
                    yield os.path.basename(n), json.loads(f.read().decode('utf-8'))
    else:
        raise SystemExit(f"Unbekannte Quelle: {src}")

def compile_patterns(schema):
    rx = {}
    for sec in ('ATO','SEM'):
        for m in schema.get(sec, []):
            try:
                rx[m['id']] = re.compile(m['pattern'])
            except Exception as e:
                print(f"[WARN] Regex-Fehler in {m['id']}: {e}")
    return rx

def count_markers(messages, rx):
    counts = {k:0 for k in rx.keys()}
    msg_hits = []
    for m in messages:
        text = (m.get('text') or '').strip()
        hit = []
        for mid, pat in rx.items():
            if pat.search(text):
                counts[mid]+=1
                hit.append(mid)
        msg_hits.append({"id": m.get("id"), "hits": hit})
    return counts, msg_hits

def top(items, n=5):
    return sorted(items.items(), key=lambda kv: kv[1], reverse=True)[:n]

def main():
    ap = argparse.ArgumentParser(description="Detect-Quick: Chunks (Ordner/ZIP) → Marker-Index")
    ap.add_argument('--chunks', required=True, help="Pfad zu Ordner oder ZIP mit chunk_###.json")
    ap.add_argument('--schema', default=None, help="Schema JSON (optional; sonst Fallback)")
    ap.add_argument('--out', default='.', help="Ausgabe-Ordner")
    args = ap.parse_args()

    schema = load_schema(args.schema)
    rx = compile_patterns(schema)
    os.makedirs(args.out, exist_ok=True)

    detect = {"detectIndex": [], "generatedAt": datetime.utcnow().isoformat()+"Z"}
    total_counts = {k:0 for k in rx.keys()}

    for fname, obj in iter_chunks(args.chunks):
        messages = obj.get('messages') or obj if isinstance(obj, list) else []
        cts, msg_hits = count_markers(messages, rx)
        for k,v in cts.items(): total_counts[k]+=v

        # split ATO vs SEM
        ato_ids = set([m['id'] for m in schema.get('ATO',[])])
        sem_ids = set([m['id'] for m in schema.get('SEM',[])])

        top_atoms = [{"id":k,"count":v} for k,v in top({k:v for k,v in cts.items() if k in ato_ids}, 5)]
        top_sems  = [{"id":k,"count":v} for k,v in top({k:v for k,v in cts.items() if k in sem_ids}, 5)]

        # simple "hotspots": Fenster mit vielen E-Markern
        Eset = set(schema.get('metrics',{}).get('sets',{}).get('E',[]))
        window = 12
        hotspots = []
        if messages:
            hits = [len([h for h in msg_hits[i]["hits"] if h in Eset]) for i in range(len(messages))]
            i=0
            while i < len(hits):
                if sum(hits[i:i+window]) >= 4:  # Schwelle
                    start=i
                    j=i+window
                    while j < len(hits) and hits[j]>0:
                        j+=1
                    hotspots.append({
                        "startMsg": messages[start].get("id"),
                        "endMsg": messages[min(j-1, len(messages)-1)].get("id"),
                        "eLoad": int(sum(hits[start:j]))
                    })
                    i=j
                else:
                    i+=1

        detect["detectIndex"].append({
            "chunkName": fname,
            "topAtoms": top_atoms,
            "topSEM": top_sems,
            "hotSpots": hotspots
        })

    with open(os.path.join(args.out, 'detect_index.json'), 'w', encoding='utf-8') as f:
        json.dump(detect, f, ensure_ascii=False, indent=2)

    with open(os.path.join(args.out, 'marker_counts.json'), 'w', encoding='utf-8') as f:
        json.dump({"total": total_counts}, f, ensure_ascii=False, indent=2)

    print(f"[OK] detect_index.json & marker_counts.json in {args.out}")

if __name__ == '__main__':
    main()
